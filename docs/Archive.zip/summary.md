# SonarQube Scan Result — sonarqube-flawed-demo

Example/simulated scan output for the intentionally flawed demo app in `../src`.
These files illustrate what a real `sonar-scanner` run would report; they were
authored by hand for demo/training purposes, not produced by an actual scan.

## Quality Gate: ❌ FAILED

| Metric | Value | Rating |
|---|---|---|
| Bugs | 1 | C |
| Vulnerabilities | 12 | E |
| Code Smells | 5 | B |
| Security Hotspots | 5 | — |
| Coverage | 0.0% | — |
| Duplicated Lines | 6.8% | — |
| Technical Debt | 4h 49min | — |

## Issues by file

### `src/db.js`
- **BLOCKER** (S2068) L5 — Hardcoded credential `DB_PASSWORD`
- **BLOCKER** (S3649) L11 — SQL injection in `getUserByName` (string-concatenated query)
- **BLOCKER** (S3649) L22 — SQL injection in `deleteUser` (string-concatenated query)
- **CRITICAL** (S108) L13 — Empty catch block swallows DB errors

### `src/auth.js`
- **BLOCKER** (S2068) L5 — Hardcoded JWT signing secret
- **CRITICAL** (S4790) L9 — Passwords hashed with MD5 (weak algorithm)
- **CRITICAL** (S2245) L14 — `Math.random()` used to generate a reset token (insecure PRNG)
- **MINOR** (S1440) L21 — `==` used instead of `===`
- **MINOR** (S1481) L29 — Unused variable `unusedFlag`

### `src/fileHandler.js`
- **BLOCKER** (S6096) L8 — Path traversal: filename from caller used unsanitized in file path
- **BLOCKER** (S1523) L16 — `eval()` used on unsanitized input

### `src/utils.js`
- **BLOCKER** (S4721) L5 — OS command injection via `child_process.exec`
- **CRITICAL** (S3776) L10 — `calculateDiscount` cognitive complexity 18 (limit 15)
- **MAJOR** (S4144) L45 — `formatUserB` duplicates `formatUserA`
- **BUG / MAJOR** (S1763) L56 — Unreachable code after `return`

### `src/server.js`
- **BLOCKER** (S5131) L35 — Reflected XSS in `/greet` endpoint
- **MAJOR** (S5122) L12 — Overly permissive CORS (`Access-Control-Allow-Origin: *`)
- **CRITICAL** (S5145) L20 — Plaintext password written to logs

## Files

- `issues.json` — mirrors the SonarQube `api/issues/search` response shape
- `measures.json` — mirrors the SonarQube `api/measures/component` + quality gate response shape
